﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using onlineBanking.Models;

namespace onlineBanking.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult login()
    {
        return View();
    }

      public IActionResult map()
    {
        return View();
    }

      public IActionResult upgrade()
    {
        return View();
    }

      public IActionResult maps()
    {
        return View();
    }

      public IActionResult profile()
    {
        return View();
    }

      public IActionResult register()
    {
        return View();
    }

      public IActionResult tables()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
