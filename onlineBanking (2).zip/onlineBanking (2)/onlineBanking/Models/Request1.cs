﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class Request1
{
    public int RequestId { get; set; }

    public byte[] RequestDate { get; set; } = null!;

    public string? RequestStatus { get; set; }

    public string? RequestType { get; set; }
}
