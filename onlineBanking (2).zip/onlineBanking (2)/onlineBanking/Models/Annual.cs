﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class Annual
{
    public int? RegisteredId { get; set; }

    public int? AnnualId { get; set; }

    public virtual AnnualStatement? AnnualNavigation { get; set; }

    public virtual Registered? Registered { get; set; }
}
