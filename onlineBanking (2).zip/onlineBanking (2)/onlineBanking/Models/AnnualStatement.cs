﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class AnnualStatement
{
    public int StatementId { get; set; }

    public DateTime? StatementDate { get; set; }

    public string? StatementDetails { get; set; }
}
