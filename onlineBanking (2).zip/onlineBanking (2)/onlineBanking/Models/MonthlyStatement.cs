﻿using System;
using System.Collections.Generic;

namespace onlineBanking.Models;

public partial class MonthlyStatement
{
    public int MonthStatementId { get; set; }

    public DateTime? MonthStatementDate { get; set; }

    public string? MonthStatementDetails { get; set; }
}
